var builder = WebApplication.CreateBuilder(args);

var connStr = builder.Configuration.GetConnectionString("Default")
    ?? throw new InvalidOperationException("Missing connection string.");

builder.Services.AddSingleton(new RegistrationService(connStr));

var app = builder.Build();

app.MapGet("/api/registrations/lookup", (string email, RegistrationService svc) =>
{
    try
    {
        var id = svc.GetUserRegistration(email);
        return id is null ? Results.NotFound() : Results.Ok(new { registrationId = id });
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(ex.Message);
    }
});

app.Run();