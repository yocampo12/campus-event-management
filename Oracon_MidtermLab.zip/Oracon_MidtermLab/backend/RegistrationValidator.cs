using System;

public interface IEventRepository
{
    int GetCapacity(int eventId);
    int GetConfirmedCount(int eventId);
}

public class RegistrationValidator
{
    private const string AllowedDomain = "univ.edu.ph";
    private readonly IEventRepository _repo;

    public RegistrationValidator(IEventRepository repo)
    {
        _repo = repo ?? throw new ArgumentNullException(nameof(repo));
    }

    public bool IsValidStudentEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email)) return false;

        var parts = email.Trim().Split('@');
        return parts.Length == 2
            && parts[0].Length > 0
            && !parts[0].Contains(' ')
            && parts[1].Equals(AllowedDomain, StringComparison.OrdinalIgnoreCase);
    }

    public bool HasSeatAvailable(int eventId)
    {
        int capacity = _repo.GetCapacity(eventId);
        int confirmed = _repo.GetConfirmedCount(eventId);
        return confirmed < capacity;
    }
}