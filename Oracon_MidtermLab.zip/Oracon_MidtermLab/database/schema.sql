-- Online Campus Event Management System | SQL Server (T-SQL) | 3NF
-- Drop in dependency order (re-runnable)
IF OBJECT_ID('dbo.Registrations', 'U') IS NOT NULL DROP TABLE dbo.Registrations;
IF OBJECT_ID('dbo.Events', 'U')        IS NOT NULL DROP TABLE dbo.Events;
IF OBJECT_ID('dbo.Venues', 'U')        IS NOT NULL DROP TABLE dbo.Venues;
IF OBJECT_ID('dbo.Users', 'U')         IS NOT NULL DROP TABLE dbo.Users;
GO

CREATE TABLE dbo.Users (
    UserId     INT IDENTITY(1,1) NOT NULL,
    FullName   NVARCHAR(100)     NOT NULL,
    Email      NVARCHAR(255)     NOT NULL,
    Role       VARCHAR(10)       NOT NULL CONSTRAINT DF_Users_Role DEFAULT ('Student'),
    CreatedAt  DATETIME2(0)      NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT PK_Users PRIMARY KEY CLUSTERED (UserId),
    CONSTRAINT UQ_Users_Email UNIQUE (Email),
    CONSTRAINT CK_Users_Role CHECK (Role IN ('Student', 'Admin')),
    CONSTRAINT CK_Users_Email CHECK (Email LIKE '_%@_%._%')
);
GO

CREATE TABLE dbo.Venues (
    VenueId    INT IDENTITY(1,1) NOT NULL,
    VenueName  NVARCHAR(100)     NOT NULL,
    Location   NVARCHAR(200)     NULL,
    CONSTRAINT PK_Venues PRIMARY KEY CLUSTERED (VenueId),
    CONSTRAINT UQ_Venues_VenueName UNIQUE (VenueName)
);
GO

CREATE TABLE dbo.Events (
    EventId        INT IDENTITY(1,1) NOT NULL,
    Title          NVARCHAR(150)     NOT NULL,
    Description    NVARCHAR(1000)    NULL,
    VenueId        INT               NOT NULL,
    CreatedBy      INT               NOT NULL,
    StartDateTime  DATETIME2(0)      NOT NULL,
    EndDateTime    DATETIME2(0)      NOT NULL,
    Capacity       INT               NOT NULL,
    CONSTRAINT PK_Events PRIMARY KEY CLUSTERED (EventId),
    CONSTRAINT FK_Events_Venues FOREIGN KEY (VenueId)
        REFERENCES dbo.Venues (VenueId) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT FK_Events_Users FOREIGN KEY (CreatedBy)
        REFERENCES dbo.Users (UserId) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT CK_Events_Capacity CHECK (Capacity > 0),
    CONSTRAINT CK_Events_Dates CHECK (EndDateTime > StartDateTime)
);
GO

CREATE TABLE dbo.Registrations (
    RegistrationId INT IDENTITY(1,1) NOT NULL,
    UserId         INT               NOT NULL,
    EventId        INT               NOT NULL,
    RegisteredAt   DATETIME2(0)      NOT NULL CONSTRAINT DF_Registrations_RegisteredAt DEFAULT (SYSUTCDATETIME()),
    Status         VARCHAR(10)       NOT NULL CONSTRAINT DF_Registrations_Status DEFAULT ('Confirmed'),
    CONSTRAINT PK_Registrations PRIMARY KEY CLUSTERED (RegistrationId),
    CONSTRAINT FK_Registrations_Users FOREIGN KEY (UserId)
        REFERENCES dbo.Users (UserId) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT FK_Registrations_Events FOREIGN KEY (EventId)
        REFERENCES dbo.Events (EventId) ON DELETE CASCADE ON UPDATE NO ACTION,
    CONSTRAINT UQ_Registrations_User_Event UNIQUE (UserId, EventId),
    CONSTRAINT CK_Registrations_Status CHECK (Status IN ('Confirmed', 'Cancelled'))
);
GO

-- Non-clustered indexes on ALL foreign key columns
CREATE NONCLUSTERED INDEX IX_Events_VenueId        ON dbo.Events (VenueId);
CREATE NONCLUSTERED INDEX IX_Events_CreatedBy      ON dbo.Events (CreatedBy);
CREATE NONCLUSTERED INDEX IX_Registrations_UserId  ON dbo.Registrations (UserId);
CREATE NONCLUSTERED INDEX IX_Registrations_EventId ON dbo.Registrations (EventId);
GO