const ALLOWED_DOMAIN = "@univ.edu.ph";

const events = [
  { id: 1, title: "Tech Innovation Summit", date: "2026-10-20", venue: "Main Auditorium", capacity: 100, img: "https://placehold.co/400x200?text=Tech+Summit", alt: "Banner for the Tech Innovation Summit" },
  { id: 2, title: "Campus Job Fair", date: "2026-11-05", venue: "Gymnasium", capacity: 3, img: "https://placehold.co/400x200?text=Job+Fair", alt: "Banner for the Campus Job Fair" },
  { id: 3, title: "Intramurals Opening", date: "2026-11-15", venue: "Oval Field", capacity: 200, img: "https://placehold.co/400x200?text=Intramurals", alt: "Banner for the Intramurals opening ceremony" }
];

let registrations = []; // { eventId, name, email, registeredAt }

const catalog = document.getElementById("catalog");
const eventSelect = document.getElementById("eventSelect");
const adminEvent = document.getElementById("adminEvent");
const attendeeBody = document.getElementById("attendeeBody");
const form = document.getElementById("reg-form");
const message = document.getElementById("message");

function seatsLeft(eventId) {
  const ev = events.find(e => e.id === eventId);
  return ev.capacity - registrations.filter(r => r.eventId === eventId).length;
}

function renderCatalog() {
  catalog.querySelectorAll("article").forEach(a => a.remove());
  events.forEach(ev => {
    const card = document.createElement("article");
    card.innerHTML = `
      <img src="${ev.img}" alt="${ev.alt}">
      <h3>${ev.title}</h3>
      <p><time datetime="${ev.date}">${ev.date}</time> &middot; ${ev.venue}</p>
      <p>Seats left: <strong>${seatsLeft(ev.id)}</strong></p>
      <button type="button" data-id="${ev.id}" aria-label="Register for ${ev.title}">Register</button>
    `;
    catalog.appendChild(card);
  });
  catalog.querySelectorAll("button").forEach(btn => {
    btn.addEventListener("click", () => {
      eventSelect.value = btn.dataset.id;
      document.getElementById("fullName").focus();
    });
  });
}

function renderSelects() {
  const options = events.map(e => `<option value="${e.id}">${e.title}</option>`).join("");
  eventSelect.innerHTML = `<option value="">-- Choose an event --</option>` + options;
  adminEvent.innerHTML = options;
}

function renderAttendees() {
  const id = Number(adminEvent.value);
  const rows = registrations.filter(r => r.eventId === id);
  attendeeBody.innerHTML = rows.length
    ? rows.map(r => `<tr><td>${escapeHtml(r.name)}</td><td>${escapeHtml(r.email)}</td><td>${r.registeredAt}</td></tr>`).join("")
    : `<tr><td colspan="3">No attendees yet.</td></tr>`;
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str;
  return d.innerHTML;
}

function showMessage(text, type) {
  message.textContent = text;
  message.className = type;
}

form.addEventListener("submit", e => {
  e.preventDefault();
  const name = document.getElementById("fullName").value.trim();
  const email = document.getElementById("email").value.trim().toLowerCase();
  const eventId = Number(eventSelect.value);

  if (!name || !email || !eventId) return showMessage("Please complete all fields.", "error");
  if (!email.endsWith(ALLOWED_DOMAIN) || email.split("@").length !== 2 || email.startsWith("@"))
    return showMessage("Email must be a valid " + ALLOWED_DOMAIN + " address.", "error");
  if (registrations.some(r => r.eventId === eventId && r.email === email))
    return showMessage("You are already registered for this event.", "error");
  if (seatsLeft(eventId) <= 0)
    return showMessage("Sorry, this event is fully booked.", "error");

  registrations.push({ eventId, name, email, registeredAt: new Date().toLocaleString() });
  showMessage("Registration successful!", "success");
  form.reset();
  renderCatalog();
  renderAttendees();
});

adminEvent.addEventListener("change", renderAttendees);

renderSelects();
renderCatalog();
renderAttendees();