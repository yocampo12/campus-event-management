using Moq;
using Xunit;

public class RegistrationValidatorTests
{
    private readonly Mock<IEventRepository> _repoMock = new Mock<IEventRepository>();
    private RegistrationValidator CreateValidator() => new RegistrationValidator(_repoMock.Object);

    [Theory]
    [InlineData("juan.delacruz@univ.edu.ph", true)]
    [InlineData("JUAN@UNIV.EDU.PH", true)]
    [InlineData("  juan@univ.edu.ph  ", true)]
    [InlineData(null, false)]
    [InlineData("", false)]
    [InlineData("   ", false)]
    [InlineData("juan@gmail.com", false)]
    [InlineData("juan@univ.edu.ph.evil.com", false)]
    [InlineData("@univ.edu.ph", false)]
    [InlineData("juan@@univ.edu.ph", false)]
    [InlineData("ju an@univ.edu.ph", false)]
    public void IsValidStudentEmail_ReturnsExpected(string email, bool expected)
    {
        var validator = CreateValidator();
        Assert.Equal(expected, validator.IsValidStudentEmail(email));
    }

    [Fact]
    public void HasSeatAvailable_ReturnsTrue_WhenSeatsRemain()
    {
        _repoMock.Setup(r => r.GetCapacity(1)).Returns(100);
        _repoMock.Setup(r => r.GetConfirmedCount(1)).Returns(40);

        Assert.True(CreateValidator().HasSeatAvailable(1));

        _repoMock.Verify(r => r.GetCapacity(1), Times.Once);
        _repoMock.Verify(r => r.GetConfirmedCount(1), Times.Once);
    }

    [Fact]
    public void HasSeatAvailable_ReturnsFalse_WhenEventIsFull()
    {
        _repoMock.Setup(r => r.GetCapacity(2)).Returns(50);
        _repoMock.Setup(r => r.GetConfirmedCount(2)).Returns(50);

        Assert.False(CreateValidator().HasSeatAvailable(2));
    }

    [Fact]
    public void Constructor_Throws_WhenRepositoryIsNull()
    {
        Assert.Throws<System.ArgumentNullException>(() => new RegistrationValidator(null));
    }
}